public class Consumatore implements Runnable {
    private Buffer buffer;
    private int numeroconsumato;


    Consumatore(Buffer buffer) {
        this.buffer = buffer;
    }

    public void run() {
        try {
            while (true) {
                numeroconsumato = buffer.getCoda();
                if (numeroconsumato >= 0) {
                    System.out.println("Consumo il numero: " + numeroconsumato);
                } else {
                    System.out.println("Vuota!");
                    Thread.sleep(500);
                }
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
