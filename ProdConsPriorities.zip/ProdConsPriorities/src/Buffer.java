public class Buffer {
    private int[] coda;
    private int capienzaMax = 100; //capienza decisa da me
    private int indice = 0;
    private int numInCoda;
    private int numeripari;
    private int numeridispari;
    private boolean nprimo;

    public Buffer() {
        coda = new int[capienzaMax];
    }

    public synchronized void addCoda(int numero) {
        if (indice < capienzaMax) {
            coda[indice] = numero;
            indice++;
        } else {
            System.out.println("Coda piena");
        }
    }



    public synchronized int getCoda() {
        if (indice > 0) {
            for(int i = indice; i>0; i++){
                
            }

            indice--;
            numInCoda = coda[indice];
            if(numInCoda %2==0 ){
                numeripari++;
            }else{
                numeridispari++;
            }
            System.out.println("statistica num pari/dispari: "+numeripari+", "+numeridispari);
            return numInCoda;
        }
        return -1;
    }
}
