public class Buffer {
    private int[] coda;
    private int capienzaMax = 100;
    private int indice = 0;
    private int numInTesta;

    public Buffer() {
        coda = new int[capienzaMax];
    }

    public synchronized void addCoda(int numero) {
        if (indice < capienzaMax) {
            coda[indice] = numero;
            indice++;
        } else {
            System.out.println("Coda piena");
        }
    }




    public synchronized int getTesta() {
        if (indice > 0) {
            numInTesta = coda[0];


            for (int i = 1; i < indice; i++) {
                coda[i - 1] = coda[i];
            }

            indice--;
            return numInTesta;
        } else {

            return -1;
        }
    }
}
