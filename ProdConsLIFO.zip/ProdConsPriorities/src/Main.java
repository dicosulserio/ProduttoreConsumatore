import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Numero di consumatori: ");
        int t = input.nextInt();

        Buffer buffer = new Buffer();

        Produttore produttore = new Produttore(buffer);
        Consumatore consumatore = new Consumatore(buffer);
        Thread prod = new Thread(produttore);
        prod.start();
        for (int i = 0; i < t; i++) {
            Thread cons = new Thread(consumatore);
            cons.start();
        }
    }
}
