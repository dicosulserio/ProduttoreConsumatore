
import java.util.Random;

public class Produttore implements Runnable {
    private Buffer buffer;
    private Random rand = new Random();
    private int numero;
    private int Xms;

    Produttore (Buffer buffer){
        this.buffer = buffer;
    }

    public void run() {
        try {
            while (true) {
                numero = rand.nextInt(1024); //genero numero
                Xms = rand.nextInt(100, 1000); //genero ritardo

                Thread.sleep(Xms);
                buffer.addCoda(numero);

            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        System.out.println("produttore");
    }
}
